module de.jensd.fx.fontawesomefx.fontawesome {

    requires java.logging;

    requires javafx.controls;
    requires javafx.fxml;

    requires de.jensd.fx.fontawesomefx.commons;

    exports de.jensd.fx.glyphs.fontawesome;
    exports de.jensd.fx.glyphs.fontawesome.demo;
    exports de.jensd.fx.glyphs.fontawesome.utils;

}