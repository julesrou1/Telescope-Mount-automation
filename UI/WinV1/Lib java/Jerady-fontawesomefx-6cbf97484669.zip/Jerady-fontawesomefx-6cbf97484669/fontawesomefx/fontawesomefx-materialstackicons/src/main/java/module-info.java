module de.jensd.fx.fontawesomefx.materialstackicons {
    requires java.logging;
    requires javafx.controls;
    requires javafx.fxml;

    requires de.jensd.fx.fontawesomefx.commons;
    requires de.jensd.fx.fontawesomefx.materialicons;

    exports de.jensd.fx.glyphs.materialstackicons;
    exports de.jensd.fx.glyphs.materialstackicons.demo;

}