module de.jensd.fx.fontawesomefx.emojione {
    requires java.logging;
    requires javafx.controls;
    requires javafx.fxml;

    requires de.jensd.fx.fontawesomefx.commons;

    exports de.jensd.fx.glyphs.emojione;
    exports de.jensd.fx.glyphs.emojione.demo;
}