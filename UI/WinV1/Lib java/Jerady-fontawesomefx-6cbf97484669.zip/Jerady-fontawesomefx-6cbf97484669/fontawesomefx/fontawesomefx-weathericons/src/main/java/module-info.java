module de.jensd.fx.fontawesomefx.weathericons {
    requires java.logging;
    requires javafx.controls;
    requires javafx.fxml;

    requires de.jensd.fx.fontawesomefx.commons;

    exports de.jensd.fx.glyphs.weathericons;
    exports de.jensd.fx.glyphs.weathericons.demo;
    exports de.jensd.fx.glyphs.weathericons.utils;
}