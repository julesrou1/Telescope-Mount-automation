module de.jensd.fx.fontawesomefx.commons {

    requires java.logging;

    requires javafx.controls;
    requires javafx.fxml;

    exports de.jensd.fx.glyphs;
}