module de.jensd.fx.fontawesomefx.octicons {
    requires java.logging;
    requires javafx.controls;
    requires javafx.fxml;

    requires de.jensd.fx.fontawesomefx.commons;

    exports de.jensd.fx.glyphs.octicons;
    exports de.jensd.fx.glyphs.octicons.demo;
    exports de.jensd.fx.glyphs.octicons.utils;
}