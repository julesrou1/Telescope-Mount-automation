module de.jensd.fx.fontawesomefx.icons525 {
    requires java.logging;
    requires javafx.controls;
    requires javafx.fxml;

    requires de.jensd.fx.fontawesomefx.commons;

    exports de.jensd.fx.glyphs.icons525;
    exports de.jensd.fx.glyphs.icons525.demo;
    exports de.jensd.fx.glyphs.icons525.utils;

}