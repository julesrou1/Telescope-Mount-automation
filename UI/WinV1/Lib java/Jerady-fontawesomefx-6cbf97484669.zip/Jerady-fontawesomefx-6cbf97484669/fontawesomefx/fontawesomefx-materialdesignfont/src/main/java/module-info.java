module de.jensd.fx.fontawesomefx.materialdesignicons {
    requires java.logging;
    requires javafx.controls;
    requires javafx.fxml;

    requires de.jensd.fx.fontawesomefx.commons;

    exports de.jensd.fx.glyphs.materialdesignicons;
    exports de.jensd.fx.glyphs.materialdesignicons.demo;
    exports de.jensd.fx.glyphs.materialdesignicons.utils;

}